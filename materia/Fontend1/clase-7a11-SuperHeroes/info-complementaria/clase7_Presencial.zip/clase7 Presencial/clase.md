# Clase 7 Modelo de Cajas
## Propiedades Modelo de Caja
- display    
- width
- height 
- padding
- border
- border-radius
- margin

- box-sizing

## Position
- static
- relative
- absolute
- fixed
- sticky

## z-index